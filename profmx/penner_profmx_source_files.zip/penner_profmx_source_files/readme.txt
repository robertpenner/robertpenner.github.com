
=======================================================================

  Robert Penner's Programming Macromedia Flash MX
 
  Source Files v1.0
  Oct. 29, 2002
 
  Book home page: 
  http://www.robertpenner.com/profmx
  http://www.amazon.com/exec/obidos/ASIN/0072223561/robertpennerc-20
 
=======================================================================

